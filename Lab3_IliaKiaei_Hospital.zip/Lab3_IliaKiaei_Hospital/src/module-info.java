/**
 * 
 */
/**
 * 
 */
module Lab5_IliaKiaei_Hospital {
}