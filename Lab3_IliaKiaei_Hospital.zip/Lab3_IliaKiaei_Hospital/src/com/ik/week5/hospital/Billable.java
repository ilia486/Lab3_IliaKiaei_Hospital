package com.ik.week5.hospital;

public interface Billable {

	void generateBill();
}
