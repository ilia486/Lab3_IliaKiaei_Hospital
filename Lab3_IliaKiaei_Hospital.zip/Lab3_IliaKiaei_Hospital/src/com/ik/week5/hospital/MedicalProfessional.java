package com.ik.week5.hospital;

public interface MedicalProfessional {

	void prescribeMedication();
}
