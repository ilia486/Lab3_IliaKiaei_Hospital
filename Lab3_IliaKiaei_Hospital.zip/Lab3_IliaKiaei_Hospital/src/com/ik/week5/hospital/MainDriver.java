package com.ik.week5.hospital;

public class MainDriver {

	public static void main(String[] args) {

		// ---- Create objects ----
		Doctor doctor = new Doctor(101, "Sarah Lee", 45, "Cardiology", 150.00);
		Nurse nurse = new Nurse(201, "James Carter", 32, "Pediatrics", "Night");
		Surgeon surgeon = new Surgeon(102, "Michael Chen", 50, "Orthopedics", 300.00,
				"Knee Replacement", "OR-3");
		EmergencyDoctor erDoctor = new EmergencyDoctor(103, "Amira Khan", 38, "Emergency Medicine", 200.00, 12);

		// ---- Display details ----
		System.out.println("===== Object Details =====");
		doctor.displayDetails();
		System.out.println();
		nurse.displayDetails();
		System.out.println();
		surgeon.displayDetails();
		System.out.println();
		erDoctor.displayDetails();

		// ---- Specialized methods ----
		System.out.println("\n===== Specialized Methods =====");
		doctor.diagnosePatient();
		nurse.assistPatient();
		surgeon.performSurgery();
		surgeon.diagnosePatient(); // inherited from Doctor (multilevel)
		erDoctor.handleEmergency();

		// ---- Method overriding ----
		System.out.println("\n===== Method Overriding: performDuties() =====");
		doctor.performDuties();
		nurse.performDuties();
		surgeon.performDuties();
		erDoctor.performDuties();

		// ---- Polymorphism using a Person reference ----
		System.out.println("\n===== Polymorphism (Person reference) =====");
		Person person;

		person = new Doctor(104, "Laura Smith", 41, "Neurology", 180.00);
		person.performDuties();

		person = new Nurse(202, "Olivia Brown", 29, "ICU", "Day");
		person.performDuties();

		person = new Surgeon(105, "David Park", 48, "Cardiac Surgery", 350.00, "Bypass", "OR-1");
		person.performDuties();

		person = new EmergencyDoctor(106, "Noah Wilson", 36, "Trauma", 220.00, 5);
		person.performDuties();

		// ---- Interface methods via EmergencyDoctor ----
		System.out.println("\n===== Interface Methods (EmergencyDoctor) =====");
		erDoctor.prescribeMedication();
		erDoctor.generateBill();

		// Interface references
		MedicalProfessional mp = erDoctor;
		Billable billable = erDoctor;
		mp.prescribeMedication();
		billable.generateBill();
	}
}
