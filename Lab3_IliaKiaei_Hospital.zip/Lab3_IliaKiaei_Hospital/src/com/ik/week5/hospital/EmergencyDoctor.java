package com.ik.week5.hospital;

// Multiple inheritance via interfaces: Doctor + MedicalProfessional + Billable
public class EmergencyDoctor extends Doctor implements MedicalProfessional, Billable {

	private int emergencyCasesHandled;

	public EmergencyDoctor(int personId, String name, int age, String specialization, double consultationFee,
			int emergencyCasesHandled) {
		super(personId, name, age, specialization, consultationFee);
		this.emergencyCasesHandled = emergencyCasesHandled;
	}

	public int getEmergencyCasesHandled() {
		return emergencyCasesHandled;
	}

	public void handleEmergency() {
		emergencyCasesHandled++;
		System.out.println("Dr. " + getName() + " is handling an emergency case. Total cases handled: "
				+ emergencyCasesHandled);
	}

	@Override
	public void prescribeMedication() {
		System.out.println("Dr. " + getName() + " is prescribing emergency medication.");
	}

	@Override
	public void generateBill() {
		System.out.println("Bill generated for Dr. " + getName() + ": emergency consultation fee $"
				+ String.format("%.2f", getConsultationFee()));
	}

	@Override
	public void performDuties() {
		System.out.println("Emergency Dr. " + getName() + " is responding to urgent cases in the ER.");
	}

	@Override
	public void displayDetails() {
		super.displayDetails();
		System.out.println("Emergency Cases Handled: " + emergencyCasesHandled);
	}
}
